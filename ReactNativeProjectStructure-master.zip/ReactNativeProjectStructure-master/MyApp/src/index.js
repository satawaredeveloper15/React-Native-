import React from 'react';

import Navigator from '_navigations';

const App = () => <Navigator />;

export default App;
