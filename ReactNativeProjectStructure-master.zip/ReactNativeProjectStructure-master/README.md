# ReactNativeProjectStructure
Sample React Native project structure to start with

For details documentation please read http://www.digitstory.com/react-native-project-structure-a-handsome-way/
